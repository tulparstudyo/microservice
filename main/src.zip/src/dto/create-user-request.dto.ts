export class CreateUserRequest {
  email: string;
  password: string;
}
